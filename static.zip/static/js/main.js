// Global variables
let toastContainer;

$(document).ready(function() {
    // Initialize toast container
    $('body').append('<div class="toast-container"></div>');
    toastContainer = $('.toast-container');
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    
    // Confirm dangerous actions
    $('[data-confirm]').click(function(e) {
        if (!confirm($(this).data('confirm'))) {
            e.preventDefault();
        }
    });
    
    // Enable/disable buttons based on conditions
    checkResourceAvailability();
});

// Show toast notification
function showToast(title, message, type = 'info', duration = 5000) {
    let bgClass = 'bg-' + type;
    let icon = 'info-circle';
    
    if (type === 'success') icon = 'check-circle';
    if (type === 'danger') icon = 'exclamation-triangle';
    if (type === 'warning') icon = 'exclamation-circle';
    
    let toast = $(`
        <div class="toast align-items-center text-white ${bgClass} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="bi bi-${icon} me-2"></i>
                    <strong>${title}:</strong> ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `);
    
    toastContainer.append(toast);
    let bsToast = new bootstrap.Toast(toast[0], {delay: duration});
    bsToast.show();
    
    toast.on('hidden.bs.toast', function() {
        $(this).remove();
    });
}

// Format bytes to human readable
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Format date to relative time
function timeAgo(date) {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + ' years ago';
    
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + ' months ago';
    
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + ' days ago';
    
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + ' hours ago';
    
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + ' minutes ago';
    
    return Math.floor(seconds) + ' seconds ago';
}

// Check resource availability
function checkResourceAvailability() {
    $('[data-resource]').each(function() {
        let resource = $(this).data('resource');
        let threshold = $(this).data('threshold');
        let value = $(this).data('value');
        
        if (value >= threshold) {
            $(this).addClass('critical');
        }
    });
}

// Copy to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        showToast('Copied!', 'Text copied to clipboard', 'success');
    }, function() {
        showToast('Error', 'Failed to copy text', 'danger');
    });
}

// Confirm action with modal
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Handle AJAX errors
$(document).ajaxError(function(event, jqxhr, settings, error) {
    if (jqxhr.status === 401) {
        window.location.href = '/login';
    } else if (jqxhr.status === 403) {
        showToast('Access Denied', 'You do not have permission', 'danger');
    } else if (jqxhr.status === 404) {
        showToast('Not Found', 'Resource not found', 'warning');
    } else if (jqxhr.status === 500) {
        showToast('Server Error', 'Internal server error', 'danger');
    } else {
        showToast('Error', 'An error occurred: ' + error, 'danger');
    }
});

// Show loading overlay
function showLoading() {
    $('body').append('<div class="spinner-overlay"><div class="spinner-border text-primary" role="status"></div></div>');
}

// Hide loading overlay
function hideLoading() {
    $('.spinner-overlay').remove();
}

// Debounce function for search inputs
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Form validation
function validateForm(formId) {
    let isValid = true;
    $(`#${formId} [required]`).each(function() {
        if (!$(this).val()) {
            $(this).addClass('is-invalid');
            isValid = false;
        } else {
            $(this).removeClass('is-invalid');
        }
    });
    return isValid;
}

// Auto-refresh data
let refreshIntervals = {};

function startAutoRefresh(id, url, interval = 30000) {
    if (refreshIntervals[id]) {
        clearInterval(refreshIntervals[id]);
    }
    
    refreshIntervals[id] = setInterval(function() {
        $.getJSON(url, function(data) {
            $(document).trigger('refresh:' + id, data);
        });
    }, interval);
}

function stopAutoRefresh(id) {
    if (refreshIntervals[id]) {
        clearInterval(refreshIntervals[id]);
        delete refreshIntervals[id];
    }
}

// Export table to CSV
function exportToCSV(tableId, filename) {
    let csv = [];
    let rows = $(`#${tableId} tr`);
    
    rows.each(function() {
        let row = [];
        $(this).find('td, th').each(function() {
            row.push('"' + $(this).text().trim() + '"');
        });
        csv.push(row.join(','));
    });
    
    let csvContent = csv.join('\n');
    let blob = new Blob([csvContent], {type: 'text/csv'});
    let url = window.URL.createObjectURL(blob);
    let a = document.createElement('a');
    a.href = url;
    a.download = filename + '.csv';
    a.click();
    window.URL.revokeObjectURL(url);
}

// Chart colors
const chartColors = {
    primary: '#0d6efd',
    secondary: '#6c757d',
    success: '#198754',
    danger: '#dc3545',
    warning: '#ffc107',
    info: '#0dcaf0',
    dark: '#212529'
};

// Initialize charts
function initChart(canvasId, type, data, options = {}) {
    let ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: type,
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            ...options
        }
    });
}
